import AsyncStorage from '@react-native-community/async-storage';

export const USER_ACC_NUMBER = 'USER_ACC_NUMBER';
export const USER_PIN = 'USER_PIN';

export const onSignIn = async (accNumber, pin) => {
    try {
        await AsyncStorage.setItem(USER_ACC_NUMBER, accNumber);
        await AsyncStorage.setItem(USER_PIN, pin);
    } catch (e) {

    }
}

export const onSignOut = async () => {
    try {
        await AsyncStorage.removeItem(USER_ACC_NUMBER);
        await AsyncStorage.removeItem(USER_PIN);
    } catch (e) {

    }
}