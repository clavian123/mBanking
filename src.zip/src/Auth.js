import AsyncStorage from '@react-native-community/async-storage';

export const USER_KEY = 'auth-demo-key';

export const onSignIn = async () => {
    try {
        await AsyncStorage.setItem(USER_KEY, 'rian');
    } catch (e) {

    }
}

export const onSignOut = async () => {
    try {
        await AsyncStorage.removeItem(USER_KEY);
    } catch (e) {

    }
}