import React, { Component } from 'react';
import {
  Image,
  StyleSheet,
  TextInput,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import { connect } from 'react-redux';
import axios from 'axios'

import { onSignIn } from '../Auth';
import { login } from '../action/loginActions'

class Login extends Component {

  constructor(props){
    super(props);
    this.state = {
      accNumber: '',
      pin: '',
      checkLogin: false
    }
  }

  validateLogin = (accNumber, pin) => {
    let userLogin = {
      accNumber: accNumber,
      pin: pin
    }
    let address = "http://localhost:8080/validateLogin";

    axios.post(address, userLogin).then(
      (res) => {
        console.log(res.data);
        this.setState({ checkLogin: res.data });
      }, (error) => {
        console.log(error);
      }
    )
  }

  handleLogin = () => {
    const { accNumber, pin, checkLogin } = this.state;
    this.validateLogin(accNumber, pin);
    console.log(checkLogin)
    if (checkLogin) {
      this.props.dispatch(login(accNumber, pin));
      onSignIn(this.state.accNumber, this.state.pin);
    } else {
      alert("Your account number or PIN is wrong!");
    }
  }

  render() {
    return (
      <View style={styles.container}>
        <View style={styles.viewLogo}>
          <Image
            style={styles.imageLogo}
            source={require('../../assets/logo-project.png')}
          />
          <Text style={styles.textLogo}>M-Banking DBBS 3</Text>
        </View>
        <View style={styles.viewInput}>
          <TextInput
            value={this.state.accNumber}
            onChangeText={(accNumber) => this.setState({ accNumber: accNumber })}
            placeholder="Account Number"
            style={styles.textInput}
          ></TextInput>
          <TextInput
            value={this.state.pin}
            onChangeText={(pin) => this.setState({ pin: pin })}
            placeholder="PIN"
            style={styles.textInput}
            secureTextEntry={true}
          >
          </TextInput>
          <TouchableOpacity
            onPress={
              () => this.handleLogin()
            }
            style={styles.buttonLogin}
          >
            <Text style={styles.textLogin}>Login</Text>
          </TouchableOpacity>
        </View>
        <View style={styles.viewSignUp}>
          <Text style={styles.textSignUpLabel}>Don't have an account yet? </Text>
          <TouchableOpacity
            onPress={
              () => this.props.navigation.navigate('Register')
            }
          >
            <Text style={styles.textSignUp}>Sign Up</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }
};

const styles = StyleSheet.create({
  container: {
    alignItems: "center",
    justifyContent: "center",
    flex: 1,
    fontWeight: '500',
  },
  viewLogo: {
    alignItems: "center",
    justifyContent: "flex-end",
    flexGrow: 1,
  },
  viewInput: {
    flexGrow: 1,
    alignItems: 'center',
    justifyContent: "center",
  },
  viewSignUp: {
    flexGrow: 1,
    alignItems: 'flex-end',
    justifyContent: 'center',
    marginVertical: 16,
    flexDirection: 'row',
  },
  textInput: {
    width: 300,
    borderColor: 'black',
    borderStyle: 'solid',
    borderWidth: 1,
    borderRadius: 10,
    paddingHorizontal: 16,
    marginVertical: 10,
    fontSize: 16,
  },
  imageLogo: {
    width: 130,
    height: 130,
  },
  textLogo: {
    marginVertical: 10,
    fontSize: 20,
  },
  textLogin: {
    fontSize: 16,
    textAlign: 'center',
    color: '#ffffff',
  },
  textSignUpLabel: {
    fontSize: 16,
  },
  textSignUp: {
    fontSize: 16,
    color: 'rgb(0,0,255)',
  },
  buttonLogin: {
    borderRadius: 10,
    backgroundColor: '#1c313a',
    width: 300,
    paddingVertical: 15,
    marginVertical: 10,
  }
});

const mapStateToProps = state => ({
  state: state.login
})

export default connect(mapStateToProps)(Login)