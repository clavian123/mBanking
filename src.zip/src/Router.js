// import React from 'react';
// import { createStackNavigator } from 'react-navigation-stack';
// import { createBottomTabNavigator } from 'react-navigation-tabs';
// import { createAppContainer, createSwitchNavigator } from 'react-navigation';

// import LoginScreen from './screen/Login';
// import RegisterScreen from './screen/Register';

// import HomeScreen from './screen/home/Home';
// import BalanceInquiryScreen from './screen/home/BalanceInquiry';
// import AccountStatementPickDateScreen from './screen/home/AccountStatementPickDate';

// import TransferScreen from './screen/transfer/Transfer';
// import RegisterDestinationAccountScreen from './screen/transfer/RegisterDestinationAccount';
// import TransferToAnotherAccountScreen from './screen/transfer/TransferToAnotherAccount';

// import PaymentScreen from './screen/payment/Payment';
// import CreditCardScreen from './screen/payment/CreditCard';
// import InsuranceScreen from './screen/payment/Insurance';
// import PhoneBalanceScreen from './screen/payment/PhoneBalance'

// import AccountScreen from './screen/account/Account';

// export const SignedOut = createStackNavigator({
//     Login: {
//         screen: LoginScreen,
//         navigationOptions: {
//             headerShown: false,
//         }
//     },
//     Register: {
//         screen: RegisterScreen,
//         navigationOptions: {
//             title: "Registration"
//         }
//     }
// });

// export const HomeStackNav = createStackNavigator(
//     {
//         Home: {
//             screen: HomeScreen,
//             navigationOptions: {
//                 title: "Home"
//             }
//         },
//         BalanceInquiry: {
//             screen: BalanceInquiryScreen,
//             navigationOptions: {
//                 title: "Balance Inquiry"
//             }
//         },
//         AccountStatementPickDate: {
//             screen: AccountStatementPickDateScreen,
//             navigationOptions: {
//                 title: "Account Statement"
//             }
//         }
//     },
//     {
//         initialRouteName: 'Home',
//     }
// );

// export const TransferStackNav = createStackNavigator(
//     {
//         Transfer: {
//             screen: TransferScreen,
//             navigationOptions: {
//                 title: "Transfer"
//             }
//         },
//         RegisterDestinationAccount: {
//             screen: RegisterDestinationAccountScreen,
//             navigationOptions: {
//                 title: "Register Destination Account"
//             }
//         },
//         TransferToAnotherAccount: {
//             screen: TransferToAnotherAccountScreen,
//             navigationOptions: {
//                 title: "Transfer to Another Account"
//             }
//         }
//     },
//     {
//         initialRouteName: 'Transfer',
//     }
// );

// export const PaymentStackNav = createStackNavigator(
//     {
//         Payment: {
//             screen: PaymentScreen,
//             navigationOptions: {
//                 title: "Payment"
//             }
//         },
//         CreditCard: {
//             screen: CreditCardScreen,
//             navigationOptions: {
//                 title: "Credit Card Payment"
//             }
//         },
//         Insurance: {
//             screen: InsuranceScreen,
//             navigationOptions: {
//                 title: "Insurance Payment"
//             }
//         },
//         PhoneBalance: {
//             screen: PhoneBalanceScreen,
//             navigationOptions: {
//                 title: 'Top Up Phone Balance'
//             }
//         }
//     },
//     {
//         initialRouteName: 'Payment',
//     }
// );

// export const SignedIn = createBottomTabNavigator(
//     {
//         Home: {screen: HomeStackNav, navigationOptions: {title: "Home"}},
//         Transfer: {screen: TransferStackNav, navigationOptions: {title: "Transfer"}},
//         Payment: {screen: PaymentStackNav, navigationOptions: {title: "Payment"}},
//         Account: {screen: AccountScreen, navigationOptions: {title: "Account"}},
//     }
// );

// export const RootNavigator = (signedIn) => {
//     return createAppContainer(createSwitchNavigator(
//             {
//                 SignedIn: SignedIn,
//                 SignedOut: SignedOut,
//             },
//             {
//                 initialRouteName: signedIn ? "SignedIn" : "SignedOut"
//             }
//         )
//     );
// };

import React from 'react';
import {
    StyleSheet,
    Image,
} from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';

import LoginScreen from './screen/Login';
import RegisterScreen from './screen/Register';

import HomeScreen from './screen/home/Home';
import BalanceInquiryScreen from './screen/home/BalanceInquiry';
import AccountStatementPickDateScreen from './screen/home/AccountStatementPickDate';

import TransferScreen from './screen/transfer/Transfer';
import RegisterDestinationAccountScreen from './screen/transfer/RegisterDestinationAccount';
import TransferToAnotherAccountScreen from './screen/transfer/TransferToAnotherAccount';

import PaymentScreen from './screen/payment/Payment';
import CreditCardScreen from './screen/payment/CreditCard';
import InsuranceScreen from './screen/payment/Insurance';
import PhoneBalanceScreen from './screen/payment/PhoneBalance'

import AccountScreen from './screen/account/Account';

const Tab = createBottomTabNavigator();
const Stack = createStackNavigator();

function HomeStackScreen() {
    return (
        <Stack.Navigator
            initialRouteName="Home"
        >
            <Stack.Screen name="Home" component={HomeScreen}></Stack.Screen>
            <Stack.Screen name="BalanceInquiry" component={BalanceInquiryScreen}></Stack.Screen>
            <Stack.Screen name="AccountStatement" component={AccountStatementPickDateScreen}></Stack.Screen>
        </Stack.Navigator>
    );
}

function SignedIn() {
    const styles = StyleSheet.create({
        imageIcon: {
            width: 29,
            height: 29,
        }
    })
    return (
        <Tab.Navigator
            initialRouteName="Home"
            screenOptions={({ route }) => ({
                tabBarIcon: ({ focused, color, size }) => {
                    let iconAddress;

                    if (route.name === 'Home') {
                        iconAddress = require('../assets/icon-home.png');
                    } else if (route.name === 'Transfer') {
                        iconAddress = require('../assets/icon-transfer.png');
                    } else if (route.name === 'Payment') {
                        iconAddress = require('../assets/icon-payment.png');
                    } else if (route.name === 'Account') {
                        iconAddress = require('../assets/icon-account.png');
                    }

                    return <Image
                        source={iconAddress}
                        style={styles.imageIcon}
                    />;
                },
            })}
            tabBarOptions={{
                activeTintColor: 'black',
                inactiveTintColor: 'black',
            }}
        >
            <Tab.Screen name="Home" component={HomeStackScreen} />
            <Tab.Screen name="Account" component={AccountScreen} />
        </Tab.Navigator>
    )
}

// export const RootNavigator = (signedIn = false) => {
//     return (
//         <NavigationContainer>
//             <Stack.Navigator>
//                 {signedIn ? (
//                     <>
//                         <Stack.Screen options={{ headerShown: false }} name="SignedIn" component={SignedIn} />
//                     </>
//                 ) : (
//                         <>
//                             <Stack.Screen options={{ headerShown: false }} name="Login" component={LoginScreen} />
//                             <Stack.Screen options={{ headerShown: false }} name="Register" component={RegisterScreen} />
//                         </>
//                     )}
//             </Stack.Navigator>
//         </NavigationContainer>
//     );
// }

export class RootNavigator extends React.Component {
    
    constructor(props) {
        super(props);

        this.state = {};
    }

    render() {
        return (
            <NavigationContainer>
                <Stack.Navigator>
                    {this.props.signedIn ? (
                        <>
                            <Stack.Screen options={{ headerShown: false }} name="SignedIn" component={SignedIn} />
                        </>
                    ) : (
                            <>
                                <Stack.Screen options={{ headerShown: false }} name="Login" component={LoginScreen} />
                                <Stack.Screen options={{ headerShown: false }} name="Register" component={RegisterScreen} />
                            </>
                        )}
                </Stack.Navigator>
            </NavigationContainer>
        );
    }
}
