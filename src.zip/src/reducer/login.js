initialState = {
    accNumber: '',
    pin: '',
}

const login = (state = initialState, action) => {
    switch (action.type) {
        case 'SYNC_ASYNC':
            return({accNumber: action.accNumber, pin: action.pin});
        
        case 'LOGIN': 
            return({accNumber: action.accNumber, pin: action.pin});
        
        case 'LOGOUT':
            return({accNumber: '', pin: ''});

        default:
            return state;
    }
}

export default login;