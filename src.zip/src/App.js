import React, { Component } from 'react';
import AsyncStorage from '@react-native-community/async-storage';

import { RootNavigator } from './Router';

export default class App extends React.Component {
    
    constructor(props) {
        super(props);

        this.state = {
            signedIn: false,
            checkedSignIn: false
        };
    }

    checkedSignIn = async() => {
        var value = await AsyncStorage.getItem('auth-demo-key');
        this.setState({checkedSignIn: true});
        if (value != null) {
            this.setState({signedIn: true});
        }
    }

    componentDidMount = () => {
        this.checkedSignIn();
    }

    render() {

        const { checkedSignIn, signedIn } = this.state;

        if (!checkedSignIn) {
            return null;
        }

        return(
            <RootNavigator signedIn={this.state.signedIn}></RootNavigator>
        );
    }
}

