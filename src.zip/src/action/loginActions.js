import axios from 'axios';

import { SYNC_ASYNC, LOGIN, LOGOUT, POST_USER_LOGIN_BEGIN, POST_USER_LOGIN_SUCCESS, POST_USER_LOGIN_FAILURE } from './actionTypes';

export const syncAsync = (accNumber, pin) => ({
    type: SYNC_ASYNC,
    accNumber,
    pin,
})

export const login = (accNumber, pin) => ({
    type: LOGIN,
    accNumber,
    pin
})

export const logout = () => ({
    type: LOGOUT
})

export const postUserLoginBegin = () => ({
    type: POST_USER_LOGIN_BEGIN
});

export const postUserLoginSuccess = () => ({
    type: POST_USER_LOGIN_SUCCESS
})

export const postUserLoginFailure = error => ({
    type: POST_USER_LOGIN_FAILURE,
    error,
})

export function validateLogin(accNumber, pin) {

    let userLogin = {
        accNumber: accNumber,
        pin: pin
    }
    let address = "http://localhost:8080/validateLogin";

    return dispatch => {
        dispatch(postUserLoginBegin());
        return axios.post(address, userLogin).then(
            (res) => {
                dispatch(postUserLoginSuccess());
                console.log(res.data);
                return res.data;
            }, (error) => {
                console.log(error);
                dispatch(postUserLoginFailure(error));
            }
        )
    }
}