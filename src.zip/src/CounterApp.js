import React from 'react';
import AsyncStorage from '@react-native-community/async-storage';
import { connect } from 'react-redux';

import RootNavigator from './Router';
import { syncAsync } from './action/loginActions'

const USER_ACC_NUMBER = 'USER_ACC_NUMBER'
const USER_PIN = 'USER_PIN'

class CounterApp extends React.Component {

    constructor(props) {
        super(props);

        this.state = {
            checkedSignIn: false
        };
    }

    componentDidMount = () => {
        this.props.checkSignIn()
        this.setState({ checkedSignIn: true })
    }

    render() {

        const { checkedSignIn } = this.state;

        if (!checkedSignIn) {
            return null;
        }

        return (
            <RootNavigator />
        )
    }
}

const mapDispatchToProps = dispatch => ({
    checkSignIn: async () => {
        var accNumber = await AsyncStorage.getItem(USER_ACC_NUMBER);
        var pin = await AsyncStorage.getItem(USER_PIN);
        if (accNumber != null && pin != null) {
            dispatch(syncAsync(accNumber, pin))
        }
    }
})

export default connect(null, mapDispatchToProps)(CounterApp);

