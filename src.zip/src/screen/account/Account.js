import React, { Component } from 'react';
import {
  StyleSheet,
  View,
  Text,
  StatusBar,
  Button,
} from 'react-native';

import { onSignOut } from '../../Auth'

export default class Home extends React.Component {

  static navigationOptions = {
    title: 'Accounts',
  };

  render() {

    const { navigate } = this.props.navigation;

    return (
      <View>
        <Text>Account</Text>
        <Button
          title="Logout"
          onPress={
            () => onSignOut()
              .then(() => navigate("Login"))
          }
        />
      </View>
    );
  }
};

const styles = StyleSheet.create({

});