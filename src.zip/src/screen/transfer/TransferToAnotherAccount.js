import React, { Component } from 'react';
import {
  StyleSheet,
  View,
  Text,
} from 'react-native';

export default class TransferToAnotherAccount extends React.Component {

  render() {
    return (
      <View>
        <Text>Transfer to Another Account</Text>
      </View>
    );
  }
};

const styles = StyleSheet.create({
  
});