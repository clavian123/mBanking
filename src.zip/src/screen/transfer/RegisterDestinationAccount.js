import React, { Component } from 'react';
import {
  StyleSheet,
  View,
  Text,
  TextInput,
  Button,
} from 'react-native';

export default class RegisterDestinationAccount extends React.Component {

  render() {
    return (
      <View style={styles.container}>
        <Text style={styles.textLabel}>
          Destination Account Number
        </Text>
        <TextInput
          placeholder="Account Number"
          style={styles.textInput}
        />
        <View style={styles.viewButton}>
          <Button
            title="Register"
            style={styles.button}
          ></Button>
        </View>
      </View>
    );
  }
};

const styles = StyleSheet.create({
  container: {
    width: "100%",
    height: "100%",
    justifyContent: "center",
    alignSelf: "center",
    alignContent: "center",
    alignItems: "center",
  },
  textLabel: {
    fontSize: 18,
  },
  textInput: {
    marginVertical: 10,
    borderColor: 'black',
    borderStyle: 'solid',
    borderWidth: 1,
    borderRadius: 5,
    width: 250,
    textAlign: 'center',
  },
  viewButton: {
    marginVertical: 10,
    width: 250,
  },
  button: {
    borderRadius: 10,
  }
});