import React, { Component } from 'react';
import {
  StyleSheet,
  View,
  Text,
} from 'react-native';

export default class Insurance extends React.Component {

  render() {
    return (
      <View>
        <Text>Insurance Payment</Text>
      </View>
    );
  }
};

const styles = StyleSheet.create({
  
});