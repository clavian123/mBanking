import React, { Component } from 'react';
import {
  StyleSheet,
  View,
  Text,
} from 'react-native';

export default class CreditCard extends React.Component {

  render() {
    return (
      <View>
        <Text>Credit Card</Text>
      </View>
    );
  }
};

const styles = StyleSheet.create({
  
});