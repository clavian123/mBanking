import React, { Component } from 'react';
import {
  StyleSheet,
  View,
  Text,
} from 'react-native';

export default class PhoneBalance extends React.Component {

  render() {
    return (
      <View>
        <Text>Phone Balance Payment</Text>
      </View>
    );
  }
};

const styles = StyleSheet.create({
  
});