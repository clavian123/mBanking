import React, { Component } from 'react';
import {
  StyleSheet,
  View,
  TextInput,
  Text,
  Image,
  TouchableOpacity,
} from 'react-native';

import { onSignIn } from '../Auth';

export default class Login extends Component {
  render() {
    return (
      <View style={styles.container}>
        <View style={styles.viewLogo}>
          <Image
            style={styles.imageLogo}
            source={require('../../assets/logo-project.png')}
          />
          <Text style={styles.textLogo}>M-Banking DBBS 3</Text>
        </View>
        <View style={styles.viewInput}>
          <TextInput
            placeholder="Email"
            style={styles.textInput}
            underlineColorAndroid='rgba(0,0,0,0)'
          ></TextInput>
          <TextInput
            placeholder="PIN"
            style={styles.textInput}
            secureTextEntry={true}
          >
          </TextInput>
          <TouchableOpacity
            onPress={
              () => onSignIn()
                .then(() => this.props.navigation.navigate('SignedIn'))
            }
            style={styles.buttonLogin}
          >
            <Text style={styles.textLogin}>Login</Text>
          </TouchableOpacity>
        </View>
        <View style={styles.viewSignUp}>
          <Text style={styles.textSignUpLabel}>Don't have an account yet? </Text>
          <TouchableOpacity
            onPress={
              () => this.props.navigation.navigate('Register')
            }
          >
            <Text style={styles.textSignUp}>Sign Up</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }
};

const styles = StyleSheet.create({
  container: {
    alignItems: "center",
    justifyContent: "center",
    flex: 1,
    fontWeight: '500',
  },
  viewLogo: {
    alignItems: "center",
    justifyContent: "flex-end",
    flexGrow: 1,
  },
  viewInput: {
    flexGrow: 1,
    alignItems: 'center',
    justifyContent: "center",
  },
  viewSignUp: {
    flexGrow: 1,
    alignItems: 'flex-end',
    justifyContent: 'center',
    marginVertical: 16,
    flexDirection: 'row',
  },
  textInput: {
    width: 300,
    borderColor: 'black',
    borderStyle: 'solid',
    borderWidth: 1,
    borderRadius: 10,
    paddingHorizontal: 16,
    marginVertical: 10,
    fontSize: 16,
  },
  imageLogo: {
    width: 130,
    height: 130,
  },
  textLogo: {
    marginVertical: 10,
    fontSize: 15,
  },
  textLogin: {
    fontSize: 16,
    textAlign: 'center',
    color: '#ffffff',
  },
  textSignUpLabel: {
    fontSize: 16,
  },
  textSignUp: {
    fontSize: 16,
    color: 'rgb(0,0,255)',
  },
  buttonLogin: {
    borderRadius: 10,
    backgroundColor: '#1c313a',
    width: 300,
    paddingVertical: 15,
    marginVertical: 10,
  }
});
